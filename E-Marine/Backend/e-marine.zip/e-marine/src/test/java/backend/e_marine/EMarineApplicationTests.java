package backend.e_marine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EMarineApplicationTests {

	@Test
	void contextLoads() {
	}

}
